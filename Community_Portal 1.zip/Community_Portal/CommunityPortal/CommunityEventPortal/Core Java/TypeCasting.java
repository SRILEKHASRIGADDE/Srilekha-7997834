public class TypeCasting {

    public static void main(String[] args) {

        // Widening Casting
        int num = 10;
        double d = num;

        System.out.println("Integer value: " + num);
        System.out.println("Double value: " + d);

        // Narrowing Casting
        double price = 99.99;
        int amount = (int) price;

        System.out.println("Original double: " + price);
        System.out.println("Converted int: " + amount);
    }
}
