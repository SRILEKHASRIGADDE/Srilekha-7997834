const form =
document.querySelector("#registrationForm");

const message =
document.querySelector("#message");

form.addEventListener("submit", function(event){

    // Prevent Page Refresh
    event.preventDefault();

    const name =
    document.querySelector("#name").value;

    const email =
    document.querySelector("#email").value;

    const selectedEvent =
    document.querySelector("#event").value;

    // Validation
    if(
        name === "" ||
        email === "" ||
        selectedEvent === ""
    ){
        message.textContent =
        "Please fill all fields";

        return;
    }

    // Success Message
    message.textContent =
    `Registration Successful!

Name: ${name}

Event: ${selectedEvent}`;
});