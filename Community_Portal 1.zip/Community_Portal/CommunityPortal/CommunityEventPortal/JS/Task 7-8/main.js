// Events Array
const events = [
    {
        name: "Music Night",
        category: "Music"
    },
    {
        name: "Food Festival",
        category: "Food"
    },
    {
        name: "Dance Show",
        category: "Dance"
    }
];

// Access Elements
const container = document.querySelector("#eventContainer");
const searchBox = document.querySelector("#searchBox");
const categoryFilter = document.querySelector("#categoryFilter");

// Display Events Function
function displayEvents(eventList) {

    container.innerHTML = "";

    eventList.forEach(event => {

        const card = document.createElement("div");
        card.className = "card";

        card.innerHTML = `
            <h3>${event.name}</h3>
            <p>Category: ${event.category}</p>

            <button onclick="registerEvent('${event.name}')">
                Register
            </button>
        `;

        container.appendChild(card);

    });
}

// Register Button
function registerEvent(eventName) {
    alert(`Registered for ${eventName}`);
}

// Category Filter
categoryFilter.onchange = function () {

    const selectedCategory = categoryFilter.value;

    if (selectedCategory === "All") {

        displayEvents(events);

    } else {

        const filteredEvents = events.filter(
            event => event.category === selectedCategory
        );

        displayEvents(filteredEvents);
    }
};

// Search Event
searchBox.onkeyup = function () {

    const searchText = searchBox.value.toLowerCase();

    const searchedEvents = events.filter(
        event => event.name.toLowerCase().includes(searchText)
    );

    displayEvents(searchedEvents);
};

// Initial Display
displayEvents(events);