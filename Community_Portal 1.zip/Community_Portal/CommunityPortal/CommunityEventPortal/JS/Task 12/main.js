const loadBtn =
document.querySelector("#loadBtn");

const registerBtn =
document.querySelector("#registerBtn");

const eventList =
document.querySelector("#eventList");

const message =
document.querySelector("#message");


// GET Request
loadBtn.addEventListener("click", () => {

    fetch("https://jsonplaceholder.typicode.com/users")

    .then(response => response.json())

    .then(data => {

        eventList.innerHTML = "";

        data.slice(0, 5).forEach(event => {

            const li =
            document.createElement("li");

            li.textContent =
            event.name;

            eventList.appendChild(li);

        });

        message.textContent =
        "Events Loaded Successfully";

    })

    .catch(error => {

        message.textContent =
        "Failed to Load Events";

        console.log(error);

    });

});


// POST Request
registerBtn.addEventListener("click", () => {

    fetch(
        "https://jsonplaceholder.typicode.com/posts",
        {
            method: "POST",

            headers: {
                "Content-Type":
                "application/json"
            },

            body: JSON.stringify({
                name: "Srilekha",
                event: "Music Night"
            })
        }
    )

    .then(response => response.json())

    .then(data => {

        message.textContent =
        "Registration Successful";

        console.log(data);

    })

    .catch(error => {

        message.textContent =
        "Registration Failed";

        console.log(error);

    });

});