// Event Data
const events = [

    {
        name: "Music Night",
        category: "Music"
    },

    {
        name: "Food Festival",
        category: "Food"
    },

    {
        name: "Dance Show",
        category: "Dance"
    }

];

// DOM Elements
const container =
document.querySelector("#eventContainer");

const searchBox =
document.querySelector("#searchBox");

const categoryFilter =
document.querySelector("#categoryFilter");

const form =
document.querySelector("#registrationForm");

const message =
document.querySelector("#message");


// Display Events
function displayEvents(eventList){

    container.innerHTML = "";

    eventList.forEach(event => {

        const card =
        document.createElement("div");

        card.className = "card";

        card.innerHTML = `
            <h3>${event.name}</h3>
            <p>${event.category}</p>

            <button
            onclick="registerEvent('${event.name}')">
            Register
            </button>
        `;

        container.appendChild(card);

    });

}


// Register Event Button
function registerEvent(eventName){

    alert(`Registered for ${eventName}`);

}


// Search
searchBox.onkeyup = function(){

    const text =
    searchBox.value.toLowerCase();

    const filteredEvents =
    events.filter(event =>
        event.name
        .toLowerCase()
        .includes(text)
    );

    displayEvents(filteredEvents);

};


// Category Filter
categoryFilter.onchange = function(){

    const category =
    categoryFilter.value;

    if(category === "All"){

        displayEvents(events);

    }
    else{

        const filteredEvents =
        events.filter(event =>
            event.category === category
        );

        displayEvents(filteredEvents);

    }

};


// Form Validation
form.addEventListener("submit",
function(event){

    event.preventDefault();

    const name =
    document.querySelector("#name").value;

    const email =
    document.querySelector("#email").value;

    if(
        name === "" ||
        email === ""
    ){

        message.textContent =
        "Please fill all fields";

        return;

    }

    message.textContent =
    `Registration Successful for ${name}`;

});


// Initial Display
displayEvents(events);
card.innerHTML = `
    <h3>🎵 ${event.name}</h3>
    <p>Category: ${event.category}</p>

    <button
        class="register-btn"
        onclick="registerEvent('${event.name}')">
        Register Now
    </button>
`;