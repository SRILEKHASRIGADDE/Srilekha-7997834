// Event Class

class Event {

    constructor(name, date, seats) {
        this.name = name;
        this.date = date;
        this.seats = seats;
    }

    // Method to check seat availability
    checkAvailability() {

        if (this.seats > 0) {
            console.log(`${this.name} is available. Seats: ${this.seats}`);
        } else {
            console.log(`${this.name} is full.`);
        }

    }

}

// Create Event Objects
const event1 = new Event(
    "Community Cleanup",
    "2026-06-15",
    20
);

const event2 = new Event(
    "Food Fair",
    "2026-07-20",
    0
);

// Check Availability
event1.checkAvailability();
event2.checkAvailability();

// Display Object Properties
console.log("Event 1 Details:");

Object.entries(event1).forEach(([key, value]) => {
    console.log(`${key}: ${value}`);
});



// Event Array
const events = [];

// Add Events using push()
events.push({
    name: "Music Night",
    category: "Music"
});

events.push({
    name: "Food Festival",
    category: "Food"
});

events.push({
    name: "Dance Show",
    category: "Music"
});

console.log("All Events:");
console.log(events);

// Filter only Music Events
const musicEvents = events.filter(event =>
    event.category === "Music"
);

console.log("Music Events:");
console.log(musicEvents);

// Format Event Names using map()
const eventCards = events.map(event =>
    `Workshop on ${event.name}`
);

console.log("Formatted Event Names:");
console.log(eventCards);


