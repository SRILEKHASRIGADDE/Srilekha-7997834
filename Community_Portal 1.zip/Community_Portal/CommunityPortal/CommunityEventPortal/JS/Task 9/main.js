const container =
document.querySelector("#eventContainer");

const loading =
document.querySelector("#loading");

const loadBtn =
document.querySelector("#loadBtn");


// Mock API Function
function fetchEvents() {

    return new Promise((resolve, reject) => {

        setTimeout(() => {

            const events = [
                {
                    name: "Music Night",
                    category: "Music"
                },
                {
                    name: "Food Festival",
                    category: "Food"
                },
                {
                    name: "Dance Show",
                    category: "Dance"
                }
            ];

            resolve(events);

        }, 2000);

    });

}


// Async Await
async function loadEvents() {

    try {

        loading.textContent = "Loading Events...";

        const events = await fetchEvents();

        loading.textContent = "";

        container.innerHTML = "";

        events.forEach(event => {

            const card =
            document.createElement("div");

            card.className = "card";

            card.innerHTML = `
                <h3>${event.name}</h3>
                <p>${event.category}</p>
            `;

            container.appendChild(card);

        });

    }
    catch(error) {

        loading.textContent =
        "Error Loading Events";

    }

}


// Button Click
loadBtn.onclick = loadEvents;