export const events = [

    {
        name: "Music Night",
        category: "Music"
    },

    {
        name: "Food Festival",
        category: "Food"
    },

    {
        name: "Dance Show",
        category: "Dance"
    }

];
console.log(events);