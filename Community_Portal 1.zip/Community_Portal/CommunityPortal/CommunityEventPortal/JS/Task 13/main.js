
import { events } from "./event.js";

const container =
document.querySelector("#eventContainer");

events.forEach(event => {

    const card =
    document.createElement("div");

    card.className = "card";

    card.innerHTML = `
        <h3>${event.name}</h3>
        <p>${event.category}</p>
    `;

    container.appendChild(card);

});