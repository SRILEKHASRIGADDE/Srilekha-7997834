// const
const events = [
    {
        name: "Music Night",
        category: "Music"
    },
    {
        name: "Food Festival",
        category: "Food"
    },
    {
        name: "Dance Show",
        category: "Dance"
    }
];

// let
let totalEvents = events.length;

console.log(`Total Events: ${totalEvents}`);


// Default Parameter
function showEvent(eventName = "Unknown Event") {

    console.log(`Event Name: ${eventName}`);

}

showEvent("Music Night");
showEvent();


// Destructuring
const firstEvent = events[0];

const { name, category } = firstEvent;

console.log("Destructuring:");
console.log(name);
console.log(category);


// Spread Operator
const copiedEvents = [...events];

console.log("Copied Events:");
console.log(copiedEvents);


// Display on Screen
const output =
document.querySelector("#output");

copiedEvents.forEach(event => {

    const card =
    document.createElement("div");

    card.className = "card";

    card.innerHTML = `
        <h3>${event.name}</h3>
        <p>${event.category}</p>
    `;

    output.appendChild(card);

});