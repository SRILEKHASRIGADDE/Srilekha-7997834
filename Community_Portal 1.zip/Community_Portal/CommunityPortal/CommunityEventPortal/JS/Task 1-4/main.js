console.log("Welcome to thr Community Portal");
alert("Page Loaded Successfully");
// Event Details
const eventName = "Community Cleanup Drive";
const eventDate = "15 June 2026";

let seats = 50;

// Template Literal
const eventInfo = `Event: ${eventName} | Date: ${eventDate} | Available Seats: ${seats}`;

console.log(eventInfo);

// Registration Example
seats++;

console.log(`Seats after adding one seat: ${seats}`);

seats--;

console.log(`Seats after one registration: ${seats}`);

//  Event List
const events = [
    {
        name: "Community Cleanup",
        date: "2026-06-15",
        seats: 20
    },
    {
        name: "Music Festival",
        date: "2024-01-10",
        seats: 15
    },
    {
        name: "Food Fair",
        date: "2026-07-20",
        seats: 0
    }
];

// Current Date
const today = new Date();

// Display Valid Events
events.forEach(event => {

    const eventDate = new Date(event.date);

    if (eventDate > today && event.seats > 0) {
        console.log(
            `${event.name} | Date: ${event.date} | Seats: ${event.seats}`
        );
    }
});

// Registration Function
function registerUser(event) {

    try {

        if (event.seats <= 0) {
            throw new Error("No seats available");
        }

        event.seats--;

        console.log(`Successfully registered for ${event.name}`);

    } catch (error) {

        console.log("Registration Failed:", error.message);

    }
}

// Test Registration
registerUser(events[0]);
registerUser(events[2]);