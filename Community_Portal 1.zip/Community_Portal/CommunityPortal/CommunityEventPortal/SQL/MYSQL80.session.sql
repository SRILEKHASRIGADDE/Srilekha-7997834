/* EX:1- USER UPCOMING EVENTS */
SELECT
    u.full_name,
    u.city,
    e.title,
    e.start_date,
    e.end_date
FROM users u
JOIN registrations r
    ON u.user_id = r.user_id
JOIN events e
    ON r.event_id = e.event_id
WHERE u.city = e.city
  AND e.status = 'upcoming'
ORDER BY e.start_date;

/* EX:2 - TOP RATED QUERY */
SELECT
    e.event_id,
    e.title,
    AVG(f.rating) AS average_rating
FROM events e
JOIN feedback f
    ON e.event_id = f.event_id
GROUP BY e.event_id, e.title
ORDER BY average_rating DESC;

/* EX:3-INACTIVE USERS */
SELECT
    u.user_id,
    u.full_name,
    u.email
FROM users u
LEFT JOIN registrations r
    ON u.user_id = r.user_id
    AND r.registration_date >= CURDATE() - INTERVAL 90 DAY
WHERE r.user_id IS NULL;


/* EX:4 PEAK SESSION HOURS */

SELECT
    event_id,
    COUNT(*) AS session_count
FROM sessions
WHERE TIME(start_time) BETWEEN '10:00:00' AND '12:00:00'
GROUP BY event_id;

/* EX:5 MOST ACTIVE CITIES */

SELECT
    u.city,
    COUNT(DISTINCT r.user_id) AS total_registrations
FROM users u
JOIN registrations r
    ON u.user_id = r.user_id
GROUP BY u.city
ORDER BY total_registrations DESC
LIMIT 5;

/* EX:6 EVENT RESOURCE SUMMARY */

SELECT
    e.event_id,
    e.title,
    COUNT(r.resource_id) AS total_resources
FROM events e
JOIN resources r
    ON e.event_id = r.event_id
GROUP BY e.event_id, e.title;

/* EX:7 LOW FEEDBACK ALERTS */

SELECT
    u.full_name,
    e.title,
    f.rating,
    f.comments
FROM feedback f
JOIN users u
    ON f.user_id = u.user_id
JOIN events e
    ON f.event_id = e.event_id
WHERE f.rating < 3;

SELECT * FROM feedback;

/* EX:8- Sessions per Upcoming Event */

SELECT
    e.event_id,
    e.title,
    COUNT(s.session_id) AS total_sessions
FROM events e
LEFT JOIN sessions s
    ON e.event_id = s.event_id
WHERE e.status = 'upcoming'
GROUP BY e.event_id, e.title;

/* EX:9 - ORGANIZER EVENT SUMMARY */

SELECT
    u.user_id,
    u.full_name,
    COUNT(e.event_id) AS total_events,
    e.status
FROM users u
JOIN events e
    ON u.user_id = e.organizer_id
GROUP BY u.user_id, u.full_name, e.status;

/* EX:10 - FEEDBACK GAP */

SELECT
    e.event_id,
    e.title
FROM events e
JOIN registrations r
    ON e.event_id = r.event_id
LEFT JOIN feedback f
    ON e.event_id = f.event_id
WHERE f.feedback_id IS NULL
GROUP BY e.event_id, e.title;

/* EX:11 - DAILY NEW USER COUNT */

SELECT
    registration_date,
    COUNT(user_id) AS new_users
FROM users
WHERE registration_date >= CURDATE() - INTERVAL 7 DAY
GROUP BY registration_date
ORDER BY registration_date;

/* EX:12 - EVENT WITH MAXIMUM SESSIONS */

SELECT
    e.event_id,
    e.title,
    COUNT(s.session_id) AS total_sessions
FROM events e
JOIN sessions s
    ON e.event_id = s.event_id
GROUP BY e.event_id, e.title
ORDER BY total_sessions DESC
LIMIT 1;

/* EX:13 - AVERAGE RATING PER CITY */

SELECT
    e.city,
    AVG(f.rating) AS average_rating
FROM events e
JOIN feedback f
    ON e.event_id = f.event_id
GROUP BY e.city;

/* EX:14 - MOST REGISTERED EVENTS */

SELECT
    e.event_id,
    e.title,
    COUNT(r.registration_id) AS total_registrations
FROM events e
JOIN registrations r
    ON e.event_id = r.event_id
GROUP BY e.event_id, e.title
ORDER BY total_registrations DESC
LIMIT 3;

/* EX:15 - EVENT SESSION TIME CONFLICT */

SELECT
    s1.event_id,
    s1.session_id,
    s2.session_id
FROM sessions s1
JOIN sessions s2
    ON s1.event_id = s2.event_id
WHERE s1.session_id < s2.session_id
AND s1.start_time < s2.end_time
AND s1.end_time > s2.start_time;

/* EX:16 - UNREGISTERED ACTIVE USERS */

SELECT
    u.user_id,
    u.full_name,
    u.email
FROM users u
LEFT JOIN registrations r
    ON u.user_id = r.user_id
WHERE r.user_id IS NULL
AND u.registration_date >= CURDATE() - INTERVAL 30 DAY;

/* EX:17 - MULTI-SESSION SPEAKERS */

SELECT
    speaker_name,
    COUNT(session_id) AS total_sessions
FROM sessions
GROUP BY speaker_name
HAVING COUNT(session_id) > 1;

DESC sessions;

/* EX:18 - RESOURCE AVAILABILITY CHECK */

SELECT
    e.event_id,
    e.title
FROM events e
LEFT JOIN resources r
    ON e.event_id = r.event_id
WHERE r.resource_id IS NULL;

/* EX:19 - COMPLETED EVENTS WITH FEEDBACK SUMMARY */

SELECT
    e.event_id,
    e.title,
    COUNT(DISTINCT r.registration_id) AS total_registrations,
    AVG(f.rating) AS average_rating
FROM events e
LEFT JOIN registrations r
    ON e.event_id = r.event_id
LEFT JOIN feedback f
    ON e.event_id = f.event_id
WHERE e.status = 'completed'
GROUP BY e.event_id, e.title;

/* EX:20 - USER ENGAGEMENT INDEX */

SELECT
    u.user_id,
    u.full_name,
    COUNT(DISTINCT r.event_id) AS events_attended,
    COUNT(DISTINCT f.feedback_id) AS feedbacks_submitted
FROM users u
LEFT JOIN registrations r
    ON u.user_id = r.user_id
LEFT JOIN feedback f
    ON u.user_id = f.user_id
GROUP BY u.user_id, u.full_name;



/* EX:21 - TOP FEEDBACK PROVIDERS */

SELECT
    u.full_name,
    COUNT(f.feedback_id) AS total_feedbacks
FROM users u
JOIN feedback f
    ON u.user_id = f.user_id
GROUP BY u.user_id, u.full_name
ORDER BY total_feedbacks DESC
LIMIT 5;

/* EX:22 - DUPLICATE REGISTRATIONS CHECK */

SELECT
    user_id,
    event_id,
    COUNT(*) AS registration_count
FROM registrations
GROUP BY user_id, event_id
HAVING COUNT(*) > 1;

/* EX:23 - REGISTRATION TRENDS */

SELECT
    DATE_FORMAT(registration_date, '%Y-%m') AS month,
    COUNT(*) AS total_registrations
FROM registrations
WHERE registration_date >= CURDATE() - INTERVAL 12 MONTH
GROUP BY month
ORDER BY month;

/* EX:24 - AVERAGE SESSION DURATION */

SELECT
    event_id,
    AVG(
        TIMESTAMPDIFF(
            MINUTE,
            start_time,
            end_time
        )
    ) AS avg_duration_minutes
FROM sessions
GROUP BY event_id;

/* EX:25 - EVENTS WITHOUT SESSIONS */

SELECT
    e.event_id,
    e.title
FROM events e
LEFT JOIN sessions s
    ON e.event_id = s.event_id
WHERE s.session_id IS NULL;


SHOW DATABASES;
SELECT * FROM events;
SELECT * FROM feedback;